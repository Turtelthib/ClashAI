# ClashAI — Dashboard web · brief de design (V6)

## Contexte — le projet en 6 lignes

**ClashAI** est un bot **autonome** qui joue à *Clash of Clans* sur un émulateur Android (via ADB), en le regardant à l'écran. Il combine :
- de la **perception par vision** (plusieurs modèles CNN/YOLO qui lisent l'écran : bâtiments, troupes, compteurs, murs, état d'écran) ;
- un **agent de combat RL** (PPO) qui exécute les attaques ;
- une **couche multi-agents** (combat, château de clan, guerre de clan, chat, village, jeux de clan) ;
- à terme, un **cerveau LLM local** (Mistral, via Ollama) qui **orchestre** ces agents, se pilote **en langage naturel via le chat du clan**, et coache le RL.

## Objectif du dashboard

Un **poste de commande temps réel** dans le navigateur (réseau local) pour **superviser ET contrôler** tout le système d'un coup d'œil : ce que voit l'IA, ce qu'elle décide, ce que font les agents, les perfs de combat, et l'état des modèles. Ce n'est **pas** un document qu'on lit de haut en bas : c'est un **tableau de bord** qu'on scanne et qu'on opère. L'état qui demande attention doit sauter aux yeux (pastilles, couleurs, jauges).

## Direction visuelle souhaitée

- Ambiance **« mission control / poste de commande »** : sombre, dense mais lisible, télémétrie.
- **Monospace** pour les données/chiffres/labels (feel console), **sans-serif** propre pour le texte.
- **Accent or/ambre** (clin d'œil discret à l'or de CoC), utilisé avec parcimonie — pas partout.
- **Couleurs sémantiques** distinctes de l'accent : vert = ok/actif, orange = attention/cooldown, rouge = erreur, cyan = info/vision.
- **Thème clair ET sombre** (sombre par défaut, mais les deux soignés).
- Tabular-nums partout où des chiffres s'alignent.
- Éviter le look « IA générique » (cream + serif + terracotta ; near-black + acid-green ; tout centré ; rounded-lg partout).

## Palette (validée — base néon sombre, raffinée)

Base choisie (néon sombre, ça claque) + **assignation sémantique** (chaque couleur = un sens, pas de déco) + **ajout des couleurs d'alerte manquantes** :

- **Structure** : fond `#0a0f14` · panneau `#111827` · surface surélevée `#1a2234` · texte `#ffffff` / atténué `#8b96ad`.
- **Accents = domaines** :
  - `#00f5a0` vert → **actif / OK / action primaire**
  - `#00d9ff` cyan → **vision / perception** (overlays YOLO)
  - `#3a86ff` bleu → **données / RL / combat** (stats, courbes)
  - `#8338ec` violet → **cerveau LLM** (décision, réflexion)
- **Alertes (à AJOUTER — indispensables pour de la supervision)** :
  - `#ffb020` ambre → **attention / cooldown / sous-entraîné**
  - `#ff4d6d` rouge → **erreur**
- Garder les néons pour les **accents** (bordures, pastilles, états actifs, endpoints de courbe), **pas** en gros aplats → confort visuel.

## Structure (multi-page + sidebar persistante)

Une **toolbar/sidebar identique sur toutes les pages** (navigation) → 4 pages :

1. **Vue d'ensemble** (landing) : **Vision temps réel** (grand, centre) + bandeau "troupes de l'agent" ; à droite le **Cerveau LLM** (champ *instruction au LLM* + *décision courante* + *réflexion* + *logs actions LLM*) ; en bas les **ressources récoltées** (session en cours + cumulé toutes sessions) ; **contrôle** (Arrêter le bot) + liste "à venir".
2. **Combat / RL** : **run actuel** (tuiles étoiles moy / % 2★+ / % 3★ / destruction) + **derniers résultats d'attaque** + **comparatif run −1** (mêmes tuiles) — *alimenté par `tools/train/compare_baseline.py` + `training_log_v4.json`*.
3. **Agent** : **état des CNN en direct** (nom, temps d'inférence ms, santé ; `YOLO troupes terrain` en **ALERTE ambre** car sous-entraîné) + **scheduling des agents** (statut / cooldown / priorité).
4. **Journal** : liste **erreurs** + liste **warnings** + **timeline scrollable des décisions du cerveau LLM** (horodatée).

## Les panneaux (le contenu)

Légende statut : ✅ = données dispo aujourd'hui · ⏳ = futur (placeholder badgé dans la maquette).

| Panneau | Contenu | Source de données | Statut |
|---|---|---|---|
| **Statut global** (barre haute) | système actif/idle, émulateur connecté, mode (Farm/War/Idle), uptime | `build_world()` | ✅ |
| **Cerveau LLM** | décision courante + **raisonnement en langage naturel** + tool-calls récents + modèle utilisé + confiance | `LocalLLMBrain` (Ollama/Mistral) | ⏳ V5.3 |
| **Agents** | les 6 agents (Combat/RL, Château, Guerre de clan, Chat, Village, Jeux de clan) : statut (en cours / cooldown / inactif / à venir), priorité, dernière exécution + résultat | `AgentScheduler` | ✅ (4/6) |
| **État des CNN** *(voir détail ci-dessous)* | chaque modèle de perception : statut live + temps d'inférence + santé | PerceptionThread | ✅ |
| **Vision** | image annotée temps réel (overlays YOLO : bâtiments, troupes, zone de deploy) + état d'écran détecté + compteurs lus | PerceptionThread + flux WGC | ✅ |
| **Combat / RL** | courbe de reward (sparkline), tuiles stats (étoiles moy, % 2★+, % 3★, destruction), résumé de la dernière attaque | `training_log_v4.json` | ✅ |
| **Chat de clan** | messages du clan + réponses de l'IA (fil de discussion) | `ChatAgent` + LLM | ⏳ V5.4 |
| **Village** | ressources (or/élixir/élixir noir) avec jauges, constructeurs libres/occupés, prochaine amélioration | `VillageAgent` | ⏳ V5.2 |
| **Contrôle** | Démarrer/Arrêter, changer de mode, **champ « donner un ordre au cerveau »** | API | ✅ (basique) |
| **Journal** | flux d'événements horodatés, colorés par type (info/ok/warn/erreur) — c'est le « carnet » lisible | logs `.md` | ✅ |

## 🔬 Panneau « État des CNN » (le détail — important)

Un panneau qui montre **en direct** l'état de chaque modèle de perception, avec pour chacun : **nom**, **pastille de statut** (chargé/actif = vert · alerte = orange · erreur = rouge), **temps d'inférence** (ms), et une **métrique de santé** (nb de détections ou confiance). Les modèles :

| Modèle | Rôle | Santé montrée | Note |
|---|---|---|---|
| **Classificateur d'écran** | dit sur quel écran on est (village / prep attaque / combat…) | état + confiance (ex. `phase_attaque 96%`) | ✅ ok |
| **YOLO bâtiments** | détecte les bâtiments du village adverse | nb d'objets (ex. 77) | ✅ ok |
| **YOLO barre de troupes** | lit les icônes de la barre (troupes/sorts/héros + capacités) | nb de classes détectées | ✅ ok |
| **YOLO troupes terrain** | détecte MES troupes déployées sur le champ de bataille | nb de détections | ⚠️ **sous-entraîné** (à ré-entraîner) → l'afficher en **orange/alerte** |
| **YOLO murs** | détecte les murs → calcule la zone de déploiement | nb de segments | ✅ ok |
| **Digit CNN** | lit les compteurs (« ×12 ») de la barre de troupes | confiance moyenne | ✅ ok |

> Idée : une pastille verte qui « pulse » = actif ; afficher le **temps d'inférence** par modèle (feel télémétrie) ; le modèle `YOLO troupes terrain` doit clairement ressortir en **alerte** (c'est un problème connu). Optionnel : un mini-indicateur « cycle de perception » (ms total par frame).

## Données réalistes (pour remplir la maquette)

- Combat : **206 épisodes**, **1.63 étoile** en moyenne, **53 % de 2★+**, **12 % de 3★**, dernière attaque 2★ / 70 %.
- Compteurs lus (barre) : golem×2, sorcier×8, sorcière×13, archère×2, pekka×2, lance-bûche×1, **rage×4**, gel×2, soin×2.
- Agents : Combat = *en cours* ; Château = *cooldown 14:31* ; Guerre/Chat = *inactif* ; Village & Jeux de clan = *à venir (V5.2)*.
- Écran détecté : `phase_attaque` 96 %, 77 bâtiments, zone deploy 11/20.

## Tech cible (pour que la maquette reste réaliste à brancher)

- **Backend** : FastAPI (lit `build_world()`, `AgentScheduler.status()`, `training_log_v4.json`, le cache PerceptionThread) + **WebSocket** pour le push temps réel.
- **Flux vidéo** : pipeline de capture (WGC → frames) poussé en WebSocket, affiché dans un `<canvas>` avec overlays.
- **Front** : à définir (HTML/JS simple, htmx, ou un petit framework) — la maquette peut proposer.

## Priorités

1. **Vision + État des CNN + Combat/RL + Agents + Journal** = utiles **tout de suite** (données déjà dispo).
2. **Cerveau LLM + Chat + Village** = badgés « à venir » (placeholders qui montrent l'intention).
3. **Contrôle** = au moins Démarrer/Arrêter + mode + champ d'ordre.
